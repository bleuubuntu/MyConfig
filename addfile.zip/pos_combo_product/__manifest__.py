# -*- coding: utf-8 -*-
{
    'name': 'Combo product in POS',
    'summary': "Allaw to use combo product in POS",
    'description': 'Allaw to use combo product in POS',
    'description': """
Composed Product.
========================
Create Composed Product or Assembled Product or Kit example : Hamburger + Coca + Frites .
    """,



    'author': 'Bessam Djerad',
    'website': 'http://getuon.com',
    "support": "bessam.dj@gmail.com",

    'category': 'Point of Sale',
    'version': '11.0.0.1',
    'depends': ['point_of_sale', 'sale_stock', 'combo_product'],

    'data': [
        'security/ir.model.access.csv',
        'views/pos_pack_template_view.xml',
    ],
    'qweb': ['static/src/xml/pos_view.xml'],

    'license': "OPL-1",


    'auto_install': False,
    'installable': True,

}
