# -*- coding: utf-8 -*-
#############################################################################
#
#    Get You On
#
#############################################################################

{
    'name': 'Point of Sale Logo',
    'version': '14.0.1.0.0',
    'summary': """Point of sale debranding""",
    'description': """"This module helps you  .""",
    'category': 'Point Of Sale',
    'author': 'Get You On','Bessam Djerad'
    'company': 'Get You On',
    'website': "http://www.getuon.com",
    'depends': ['base', 'point_of_sale'],
    'data': [

        'report/report.xml',
        'report/format.xml',
        'report/client.xml',
    ],
    'qweb': [
             'static/src/xml/pos_screen.xml'],
    'images': ['static/description/banner.png'],
    'license': 'AGPL-3',
    'installable': True,
    'auto_install': False,
    'application': False,
}
