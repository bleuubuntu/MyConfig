from random import choice
from string import digits
from odoo import api, models

class ResPartner(models.Model):
    _inherit = 'res.partner'

    @api.model
    def create(self, vals):
        vals['barcode'] = '000'+"".join(choice(digits) for i in range(5))
        result = super(ResPartner, self).create(vals)
        return result