# -*- coding: utf-8 -*-
{
    "name": "POS debranding",
    "version": "13.0.1.0.0",

    'author': 'Bessam Djerad',
    'website': 'http://getuon.com',
    "support": "bessam.dj@gmail.com",

    "category": "Debranding",


    "depends": ["point_of_sale"],
    "data": ["template.xml"],
    "qweb": ["static/src/xml/pos_debranding.xml"],
    "installable": True,
}
