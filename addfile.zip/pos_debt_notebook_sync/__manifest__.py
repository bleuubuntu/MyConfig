# -*- coding: utf-8 -*-
{
    "name": """Internal Credit System""",
    "summary": """Credit payment system for festivals, food courts, etc.""",
    "category": "Point of Sale",
    "images": ["images/credit.png"],
    "version": "13.0.1.1.2",
    "application": False,
    "license": "Other OSI approved licence",  # MIT
    "depends": ["base_automation", "pos_longpolling", "pos_debt_notebook"],
    "external_dependencies": {"python": [], "bin": []},
    "data": ["views/template.xml", "data/base_action_rule.xml"],
    "qweb": [],
    "demo": [],
    "post_load": None,
    "pre_init_hook": None,
    "post_init_hook": None,
    "auto_install": False,
    "installable": True,
}
