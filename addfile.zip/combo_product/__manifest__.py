# -*- coding: utf-8 -*-
{
    'name': 'Combo Product',
    'summary': "Composed Product",
    'description': """
Composed Product.
========================
Create Composed Product or Assembled Product or Kit example : Hamburger + Coca + Frites .
    """,

    'author': 'Bessam Djerad',
    'website': 'http://getuon.com',
    "support": "bessam.dj@gmail.com",

    'category': 'Product',
    'version': '11.0.0.1',
    'depends': ['product'],

    'data': [
        'security/ir.model.access.csv',
        'views/combo_product_view.xml',
    ],

    'license': "OPL-1",

    'auto_install': False,
    'installable': True,


}
